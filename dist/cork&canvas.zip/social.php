			<div class="social">
			    <ul class="social-list">

			        <li><a href="https://www.facebook.com/cork&canvas"><i class="fa fa-facebook"></i></a></li>

			        <li><a href="https://www.twitter.com/cork&canvas"><i class="fa fa-twitter"></i></a></li>

			        <li><a href="https://www.instagram.com/cork&canvas"><i class="fa fa-instagram"></i></a></li>


			    </ul>
			</div>